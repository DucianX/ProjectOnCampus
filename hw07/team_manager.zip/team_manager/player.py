class Player:
    def __init__(self, name, num, pos):
        self.name = name
        self.num = num
        self.pos = pos

        # This class can now be used by the Team class
        # to instantiate Player objects when adding them to the team's roster.
# input("What's the player's name?")
# input(f"What's {self.name}'s number?")
# input(f"What's {self.name}'s position?")
