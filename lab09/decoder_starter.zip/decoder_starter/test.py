============================= test session starts ==============================
platform darwin -- Python 3.9.12, pytest-7.4.3, pluggy-1.3.0
rootdir: /Users/asuiro/Desktop/cs5001/lab09/decoder_starter
collected 0 items

============================ no tests ran in 0.00s =============================
